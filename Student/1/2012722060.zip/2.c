#include <stdio.h>

int main() {
	printf("bbb");
	return 0;
}
