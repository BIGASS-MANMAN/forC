#include <stdio.h>

int main() {
	printf("ccc\ncccccc");
	return 0;
}
