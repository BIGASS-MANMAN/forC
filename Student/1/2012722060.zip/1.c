#include <stdio.h>

int main() {
	printf("aaa");
	return 0;
}
